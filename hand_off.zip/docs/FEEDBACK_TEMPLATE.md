# Writer Feedback Request Template

Title: 

Draft abstract (one paragraph):

What I feel / core insights:

Specific questions for writer:
- Does the title match the contribution?
- Is the abstract clear and focused?
- Missing related work we should include?

Suggested next steps for writer:
- Review the abstract and suggest alternative titles (3 options)
- Mark which parts need expansion
