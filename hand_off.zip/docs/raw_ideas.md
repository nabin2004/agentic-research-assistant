# Raw ideas and notes

Use this file to paste raw ideas, feelings, and observations to start the research process.

Example:
- I'm curious about automating literature synthesis across arXiv and published proceedings.
- Idea: a pipeline that finds arXiv preprints, checks final venue, and extracts citation counts.

—

Add your notes below:

