This archive contains the LaTeX sources for submission to arXiv.
Build steps (on a system with TeX installed):
1. cd latex
2. sh ../scripts/build_paper.sh
If compilation fails, ensure all packages are available or include them in the archive.
